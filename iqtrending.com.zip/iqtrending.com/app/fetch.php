<?php
 require 'db.php';
//  require 'auth_session.php';
    // FETCH USER DATA
    $username = $_SESSION['username'];
if(isset($username)){
    $query = "SELECT * FROM `users` WHERE username='$username'";
  	$result = mysqli_query($db, $query);
      	if (mysqli_num_rows($result) > 0) {
      // output data of each row
      while($row = mysqli_fetch_assoc($result)) {
        $id = $row["id"];
        $name = $row["name"];
        $username = $row["username"];
        $trading_account = $row["trading_account"];
        $earnings = $row["earnings"];
      }
     }
}


?>