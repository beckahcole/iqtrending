<?php require('db.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../assets/images/fxicon.png">
    <title>Login Account</title>

	<link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap.min.css">
	
	<link rel="stylesheet" href="css/style.css">
	
	<link rel="stylesheet" href="css/skin_color.css">	

</head>
<body class="hold-transition theme-yellow bg-img" style="background-image: url(../images/auth-bg/bgimg.jpg);
background-repeat: no-repeat;
  background-attachment: fixed;" data-overlay="3">
	
	<div class="auth-2-outer row align-items-center h-p100 m-0">
		<div class="auth-2">
		  <div class="auth-logo font-size-30">
		  	<img src="../images/iqtrending.png" width="" height="60px"><br/>
			<a href="../index-2.html">Back Home</a>
		  </div>
		  <!-- /.login-logo -->
		  <div class="auth-body">
			<p class="auth-msg text-black-50">Sign in to start your investing</p>

			<form action="../app/login.php" method="POST" class="form-element">
                <?php include('errors.php'); ?>

			  <div class="form-group has-feedback">
				<input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo $username; ?>">
				<span class="ion ion-email form-control-feedback text-dark"></span>
			  </div>
			  <div class="form-group has-feedback">
				<input type="password" name="password" class="form-control" placeholder="Password">
				<span class="ion ion-locked form-control-feedback text-dark"></span>
			  </div>
			  <div class="row">
				<!-- /.col -->
				<div class="col-6">
				 <div class="fog-pwd">
					<a href="javascript:void(0)"><i class="ion ion-locked"></i> Forgot pwd?</a><br>
				  </div>
				</div>
				<!-- /.col -->
				<div class="col-12 text-center">
				  <button type="submit" name="login_user" class="btn btn-rounded my-20 btn-success">SIGN IN</button>
				</div>
				<!-- /.col -->
			  </div>
			</form>

			<div class="margin-top-30 text-center text-dark">
				<p>Don't have an account? <a href="register.php" class="text-info m-l-5">Create Account</a></p>
			</div>

		  </div>
		</div>
	
	</div>


	<!-- jQuery 3 -->
	<script src="assets/vendor_components/jquery-3.3.1/jquery-3.3.1.js"></script>
	
	<!-- fullscreen -->
	<script src="assets/vendor_components/screenfull/screenfull.js"></script>
	
	<!-- popper -->
	<script src="assets/vendor_components/popper/dist/popper.min.js"></script>
	
	<!-- Bootstrap 4.0-->
	<script src="assets/vendor_components/bootstrap/dist/js/bootstrap.min.js"></script>

</body>
</html>
