  <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<!-- Stylesheets -->
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<!-- Responsive File -->
<link href="assets/css/responsive.css" rel="stylesheet">
<!-- Color File -->
<link href="assets/css/color.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&amp;display=swap" rel="stylesheet">

<link rel="shortcut icon" href="assets/images/fxicon.png" type="image/x-icon">
<link rel="icon" href="assets/images/fxicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<title>IQTrending - Investment Home</title>
<body>

<div class="page-wrapper">
	 <!-- Preloader -->
    <div class="loader-wrap">
        <div class="preloader"><div class="preloader-close">Preloader Close</div></div>
        <div class="layer layer-one"><span class="overlay"></span></div>
        <div class="layer layer-two"><span class="overlay"></span></div>        
        <div class="layer layer-three"><span class="overlay"></span></div>        
    </div>

    <!-- Main Header -->
    <header class="main-header">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container">
				<div class="inner">
                    <div class="top-left">
                        <!--Logo-->
                        <div class="logo-box">
                            <div class="logo"><a href="index-2.html"><img src="assets/images/fxtime.png" alt="" height="80" width="140"></a></div>
                        </div>
                    </div>

                    <div class="top-middile">
                        <div class="language">
                            <span>Language:</span>
                            <form action="#" class="language-switcher">
                                <select class="selectpicker">
                                    <option value="1">English</option>
                                    <option value="1">French</option>
                                    <option value="1">Spanish</option>
                                    <option value="1">Bengli</option>
                                </select>
                            </form>
                        </div>
                        <div class="contact-info">
                            <div class="single-info">
                                <div class="icon-box"><i class="flaticon-call-1"></i></div>
                                <div class="text">Phone Number</div>
                                <h4><a href="tel:+1(970)718-2628">Protected</a></h4>
                            </div>
                            <div class="single-info">
                                <div class="icon-box"><i class="flaticon-email-4"></i></div>
                                <div class="text">Email Address</div>
                                <h4><a href="mailto:iqtrendingltd@gmail.com">iqtrendingltd@gmail.com</a></h4>
                            </div>
                        </div>
                    </div>
    
                    <div class="top-right">
                        <a href="start-trade.html" class="theme-btn btn-style-two"><span class="btn-title">View Chart</span></a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Header Upper -->
        <div class="header-upper">
            <div class="auto-container">
                <div class="inner-container">
                    <!--Nav Box-->
                    <div class="nav-outer clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><span class="icon fal fa-bars"></span></div>

                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li><a href="index-2.html">Home</a>
                                    </li>
                                    <li class="dropdown"><a href="#">About Us</a>
                                        <ul>
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="terms-and-conditions.html">Terms & Conditions</a></li>
                                            <li><a href="privacy-policy.html">Privacy Policy</a></li>
                                            <li><a href="risk-warning.html">Risk Warning</a></li>
                                            <li><a href="safety-of-fund.html">Safety Of Funds</a></li>
                                        </ul>

                                    </li>
                                    <li class="dropdown"><a href="#">Market To Trade</a>
                                        <ul>
                                            <li><a href="forex.html">Forex</a></li>
                                            <li><a href="crypto.html">Crypto Currency</a></li>
                                            <li><a href="stock.html">Stock Trading</a></li>
                                            <li><a href="commodities.html">Commodities</a></li>
											<li><a href="binary.html">Binary Option</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="faqs.html">Faqs</a>
                                    </li>
                                    <li class="dropdown"><a href="#">Package</a>
                                        <ul>
                                            <li><a href="investors.html">Investor</a></li>
                                            <li><a href="traders.html">Trader</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li><a href="contact.html">Contact</a></li>
                                </ul>
                            </div>
                        </nav>
                        <!-- Main Menu End-->
                        
                        <ul class="social-links clearfix">
                        <li><a href="app/login.php"><span class="fa fa-user"></span></a></li>
                        <li><a href="#"><span class="fa fa-chart-bar"></span></a></li>
                        <li><a href="#"><span class="fa fa-envelope-square"></span></a></li>
                        <li><a href="#"><span class="fa fa-question-square"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--End Header Upper-->

        <!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index-2.html" title=""><img src="assets/images/fxtime.png" height="80" width="140" alt="" title=""></a>
                </div>
                <!--Right Col-->
                <div class="pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu clearfix">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </nav><!-- Main Menu End-->
                </div>
            </div>
        </div><!-- End Sticky Menu -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-cancel"></span></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index-2.html"><img src="assets/images/fxtime.png" height="80" width="140" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
				<!--Social Links-->
				<div class="social-links">
					<ul class="clearfix">
						<li><a href="#"><span class="fab fa-twitter"></span></a></li>
						<li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
						<li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
						<li><a href="#"><span class="fab fa-instagram"></span></a></li>
						<li><a href="#"><span class="fab fa-youtube"></span></a></li>
					</ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->
    </header>
    <!-- End Main Header -->


        <!--Search Popup-->
    <div id="search-popup" class="search-popup">
        <div class="close-search theme-btn"><span class="flaticon-cancel"></span></div>
        <div class="popup-inner">
            <div class="overlay-layer"></div>
            <div class="search-form">
                <form method="post" action="http://azim.commonsupport.com/Finandox/index.html">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                            <input type="submit" value="Search Now!" class="theme-btn">
                        </fieldset>
                    </div>
                </form>
                <br>
                <h3>Recent Search Keywords</h3>
                <ul class="recent-searches">
                    <li><a href="#">Finance</a></li>
                    <li><a href="#">Idea</a></li>
                    <li><a href="#">Service</a></li>
                    <li><a href="#">Growth</a></li>
                    <li><a href="#">Plan</a></li>
                </ul>
            </div>
            
        </div>
    </div>

    <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "Nasdaq 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR/USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "BTC/USD"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "ETH/USD"
    },
    {
      "description": "BTN/USD",
      "proName": "FX_IDC:BTNUSD"
    },
    {
      "description": "BNB/USD",
      "proName": "BINANCE:FORUSD"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "dark",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
    <!-- Banner Section -->
    <section class="banner-section">
		<div class="banner-carousel theme_carousel owl-theme owl-carousel" data-options='{"loop": true, "margin": 0, "autoheight":true, "lazyload":true, "nav": true, "dots": true, "autoplay": true, "autoplayTimeout": 6000, "smartSpeed": 300, "responsive":{ "0" :{ "items": "1" }, "768" :{ "items" : "1" } , "1000":{ "items" : "1" }}}'>
			<!-- Slide Item -->
			<div class="slide-item">
				<div class="image-layer lazy-image" data-bg="url('assets/images/main-slider/forex1.jpg')"></div>

				<div class="auto-container">
					<div class="content-box">
                        <h3>Start trading or investing with us.</h3>
						<h2>IQ<span>Trending </span></h2>
						<div class="text">We trade forex,binary option,stock and many other <br/>asset with the best signal</div>
						<div class="btn-box"><a href="app/register.php" class="theme-btn btn-style-one"><span class="btn-title">Create Account</span></a><a href="app/login.php" class="theme-btn btn-style-two"><span class="btn-title">Login Account</span></a></div>
					</div>
				</div>
			</div>

			<!-- Slide Item -->
			<div class="slide-item">
				<div class="image-layer lazy-image" data-bg="url('assets/images/main-slider/forex2.jpg')"></div>

				<div class="auto-container">
					<div class="content-box">
                        <h3>Relax and let do the trade for you</h3>
                        <h2>IQ<span>Trending</span></h2>
                        <div class="text">We trade for millions of people around the globe with our expert in all asset</div>
                        <div class="btn-box"><a href="app/register.html" class="theme-btn btn-style-one"><span class="btn-title">Create Account</span></a><a href="app/login.html" class="theme-btn btn-style-two"><span class="btn-title">Login Account</span></a></div>
                    </div>
				</div>
			</div>

		</div>
    </section>
    <!--End Banner Section -->




   <!-- Welcome Setion -->
    <section class="welcome-section pt-0">
        <div class="auto-container">
            <div class="wrapper-box">
                <div class="row m-0">
                    <!-- Welcome Block One -->
                    <div class="welcome-block-one col-lg-4 wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                        <div class="inner-box">
                            <div class="icon-box"><span class="flaticon-analysis"></span></div>
                            <h2>Trade Analysis</h2>
                            <div class="text">Our daily technical analysis tools provides key insights on current market trends in forex, cryptocurrencies, commodities, stock and binary.</div>
                        </div>
                    </div>
                    <!-- Welcome Block One -->
                    <div class="welcome-block-one col-lg-4 wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                        <div class="inner-box" style="background-image: url(assets/images/resource/forex.jpg);">
                            <div class="icon-box"><span class="flaticon-tax"></span></div>
                            <h2>Interest</h2>
                            <div class="text">Invest us today and get best interest rate on every trede you have in your account.</div>
                        </div>
                    </div>
                    <!-- Welcome Block One -->
                    <div class="welcome-block-one col-lg-4 wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                        <div class="inner-box">
                            <div class="icon-box"><span class="flaticon-work-1"></span></div>
                            <h2>Big Percent [%] </h2>
                            <div class="text">Our percentage is high and encouraging for our investor, Both new and old investors have nice and best percent.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




<!-- About Section -->
    <section class="about-section">
        <div class="auto-container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="image-wrapper">
                        <div class="image-one">
                            <img class="lazy-image owl-lazy" src="assets/images/resource/image-spacer-for-validation.png" data-src="assets/images/resource/image-2.jpg" alt="">
                        </div>
                        <div class="image-two wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                            <div class="caption">F.</div>
                            <div class="image-outer"><img class="lazy-image owl-lazy" src="assets/images/resource/image-spacer-for-validation.png" data-src="assets/images/resource/image-3.jpg" alt=""></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="content-box">
                        <div class="sec-title">
                            <div class="sub-title">About Us</div>
                            <h2>The story behind <br>IQTrending success</h2>
                            <div class="text">IQTrending was founded in 2013 and is one of the largest and most respected brokers in the industry. We generate mass trading volume and provide vast liquidity to numerous traders and investor located around the world.
We believe in combining advanced technology with superb customer service and work diligently to meet modern traders’ needs in an ever-changing online environment. </div>
                        </div>
                        <div class="row">
                            <div class="info-column col-md-6">
                                <div class="icon-box">
                                    <div class="icon"><img src="assets/images/icons/icon-1.png" alt=""></div>
                                    <h5>Phone Number</h5>
                                    <h2>+1(970)718-2628</h2>
                                </div>
                            </div>
                            <div class="info-column col-md-6">
                                <div class="icon-box">
                                    <div class="icon"><img src="assets/images/icons/icon-2.png" alt=""></div>
                                    <h5>Email Address</h5>
                                    <h2>iqtrendingltd@gmail.com</h2>
                                </div>
                            </div>
                        </div>
                                
                    </div>
                </div>
            </div>
        </div>
    </section>






<!-- About Section -->
    <section class="about-section">
        <div class="auto-container">
            <div class="row align-items-center">


                <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js" async>
  {
  "width": "800",
  "height": "500",
  "currencies": [
    "EUR",
    "USD",
    "JPY",
    "GBP",
    "CHF",
    "AUD",
    "CAD",
    "NZD",
    "CNY"
  ],
  "isTransparent": false,
  "colorTheme": "dark",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->

            </div>
        </div>
    </section>














 <!-- Services Section -->
    <section class="services-section">
        <div class="auto-container">
            <div class="wrapper-box">
                <div class="left-column">
                    <div class="services-content">
                        <div class="sec-title light">
                            <div class="sub-title">Our Services</div>
                            <h2>What We <br>Do Here.</h2>
                        </div>
                        <div class="icon-box wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                            <div class="icon"><img src="assets/images/icons/icon-3.png" alt=""></div>
                            <h2>Trading Forex and others</h2>
                            <div class="text"></div>
                        </div>
                        <div class="icon-box wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                            <div class="icon"><img src="assets/images/icons/icon-4.png" alt=""></div>
                            <h2>Providing Tading Signal</h2>
                            <div class="text"></div>
                        </div>
                        <div class="icon-box wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                            <div class="icon"><img src="assets/images/icons/icon-5.png" alt=""></div>
                            <h2>Trading Tools For Members</h2>
                            <div class="text"></div>
                        </div>
                    </div>                        
                </div>
                <div class="right-column">
                    <!-- Fact Counter -->
                    <div class="fact-counter">
                        <div class="border-box">
                            <div class="border_top"></div>
                            <div class="border_bottom"></div>
                            <div class="border_middile"></div>
                        </div>
                        <div class="row">

                            <!--Column-->
                            <div class="column counter-column col-md-6">
                                <div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                    <div class="content">
                                        <div class="icon"><img src="assets/images/icons/icon-5.png" alt=""></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="9">0</span><span>Million+</span>
                                        </div>
                                        <div class="counter-title">Total Members</div>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column col-md-6">
                                <div class="inner wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                                    <div class="content">
                                        <div class="icon"><img src="assets/images/icons/icon-8.png" alt=""></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="37">0</span><span>Million+</span>
                                        </div>
                                        <div class="counter-title">Total Withdraw</div>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column col-md-6">
                                <div class="inner wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
                                    <div class="content">
                                        <div class="icon"><img src="assets/images/icons/icon-7.png" alt=""></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="96">0</span><span>%</span>
                                        </div>
                                        <div class="counter-title">Trading Tools</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Column-->
                            <div class="column counter-column col-md-6">
                                <div class="inner wow fadeInLeft" data-wow-delay="900ms" data-wow-duration="1500ms">
                                    <div class="content">
                                        <div class="icon"><img src="assets/images/icons/icon-9.png" alt=""></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="100">0</span><span>%</span>
                                        </div>
                                        <div class="counter-title">Market support</div>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column col-md-6">
                                <div class="inner wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
                                    <div class="content">
                                        <div class="icon"><img src="assets/images/icons/icon-10.png" alt=""></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="69">0</span><span>%</span>
                                        </div>
                                        <div class="counter-title">Data Analysis</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Column-->
                            <div class="column counter-column col-md-6">
                                <div class="inner wow fadeInLeft" data-wow-delay="900ms" data-wow-duration="1500ms">
                                    <div class="content">
                                        <div class="icon"><img src="assets/images/icons/icon-11.png" alt=""></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="200">0</span><span>+</span>
                                        </div>
                                        <div class="counter-title">Country</div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>






<!-- Team Section -->
    <section class="team-section" style="background-image: url(assets/images/background/image-3.jpg);">
        <div class="auto-container">
            <div class="sec-title text-center">
                <div class="sub-title">Our Clients</div>
                <h2>Testimony</h2>
            </div>
            <div class="row">
                <!-- Team Block One -->
                <div class="col-lg-4 team-block-one wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                    <div class="inner-box">
                        <div class="content">
                            <h3>Akshay Handge</h3>
                            <div class="text">This is the real definition of being top notch. I literally watched my account blosssom into what it is today in just under 45 days and I belive that there is more to come</div>
                        </div>
                    </div>
                </div>
                <!-- Team Block One -->
                <div class="col-lg-4 team-block-one wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                    <div class="inner-box">
                        <div class="image"><img class="lazy-image owl-lazy" src="assets/images/resource/image-spacer-for-validation.png" data-src="assets/images/resource/team-2.jpg" alt=""></div>
                        <div class="content">
                            <h3>DesuJa</h3>
                            <div class="text">
I really did not think it was possible before now to make so much profit, but here I am right now saying "Anything is just possible with Tradelive-mastery.com</div>
                        </div>
                    </div>
                </div>
                <!-- Team Block One -->
                <div class="col-lg-4 team-block-one wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                    <div class="inner-box">
                        <div class="image"><img class="lazy-image owl-lazy" src="assets/images/resource/image-spacer-for-validation.png" data-src="assets/images/resource/team-3.jpg" alt=""></div>
                        <div class="content">
                            <h3>Rahman J.</h3>
                            <div class="text">
“This is just incredible and just when I think its good enough, it just keeps getting better. Made over 4 withdarwals and I must confess that this is the best service I've ever recieved.”</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>










<!-- Contact Section -->
    <section class="contact-section">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="sec-title">
                        <div class="sub-title">Write Here</div>
                        <h2>Get In Touch</h2>
                    </div>
                    <!-- Contact Form-->
                    <div class="contact-form">
                        <form method="post" action="#">
                            <div class="row clearfix">                                    
                                <div class="col-md-12 form-group">
                                    <label for="name">Enter your name</label>
                                    <input type="text" name="username" id="name" placeholder="Enter name here......" required="">
                                    <i class="fas fa-user"></i>
                                </div>
                                
                                <div class="col-md-12 form-group">
                                    <label for="email">Enter your email</label>
                                    <input type="email" name="email" id="email" placeholder="Enter email here......" required="">
                                    <i class="fas fa-envelope"></i>
                                </div>
        
                                <div class="col-md-12 form-group">
                                    <label for="message">Enter your message</label>
                                    <textarea name="message" id="message" placeholder="Enter message here......"></textarea>
                                    <i class="fas fa-edit"></i>
                                </div>
        
                                <div class="col-md-12 form-group">
                                    <button class="theme-btn btn-style-one" type="submit" name="submit-form"><span class="btn-title">Get In Touch</span></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="sec-title">
                        <div class="sub-title">Get Us Here</div>
                        <h2>Contact Us</h2>
                    </div>
                    <div class="contact-info">
                        <div class="border-box">
                            <div class="border_top"></div>
                            <div class="border_middile"></div>
                        </div>
                        <div class="row">
                            <div class="info-column col-md-6">
                                <div class="icon-box">
                                    <div class="icon"><span class="flaticon-email-6"></span></div>
                                    <h3>Email Address</h3>
                                    <ul>
                                        <li><a href="mailto:iqtrendingltd@gmail.com">iqtrendingltd@gmail.com</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info-column col-md-6">
                                <div class="icon-box">
                                    <div class="icon"><span class="flaticon-call-1"></span></div>
                                    <h3>Phone Number</h3>
                                    <ul>
                                        <li><a href="tel:+1(970)718-2628">+1(970)718-2628</a></li>
                                        <!--<li><a href="tel:">Removed</a></li>-->
                                    </ul>
                                </div>
                            </div>
                            <div class="info-column col-md-6">
                                <div class="icon-box">
                                    <div class="icon"><span class="flaticon-location"></span></div>
                                    <h3>Office Address</h3>
                                    <ul>
                                        <li>2310 Via Tercero, San Ysidro, CA 92173, <br>United States</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info-column col-md-6">
                                <div class="icon-box">
                                    <div class="icon"><span class="flaticon-worldwide"></span></div>
                                    <h3>Web Connect</h3>
                                    <ul>
                                        <li><a href="https://iqtrending.com/">https://iqtrending.com</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>                        
                </div>
            </div>
                    
        </div>
    </section>









	<!-- Main Footer -->
    <footer class="main-footer">
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!--Column-->
                    <div class="column col-lg-4">
						<div class="footer-widget logo-widget">
                        	<div class="widget-content">
                                <div class="footer-logo">
                                    <a href="index-3.html"><img class="lazy-image" src="assets/images/resource/image-spacer-for-validation.png" data-src="assets/images/footer-logo.png" alt="" /></a>
                                </div>
                                <div class="text">Join Our Social media</div>
                                <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-telegram"></span></a></li>
                                </ul>
                            </div>
						</div>
					</div>
					
					<!--Column-->
                    <div class="column col-lg-4">
						<div class="footer-widget links-widget">
							<div class="widget-content">
								<h3>Links</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul>
                                            <li><a href="index-2.html">Home</a></li>
                                            <li><a href="about.html">About</a></li>
                                            <li><a href="terms-and-conditions.html">Terms And Conditions</a></li>
                                            <li><a href="privacy-policy.html">Privacy Policy</a></li>
                                            <li><a href="risk-warning.html">Risk Warning</a></li>
                                            <li><a href="safety-of-fund.html">Safety Of Funds</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <ul>
                                            <li><a href="faqs.html">Faqs</a></li>
                                            <li><a href="investors.html">Investors</a></li>
                                            <li><a href="traders.html">Traders</a></li>
                                            <li><a href="contact.html">Contact</a></li>
                                        </ul>
                                    </div>
                                </div>
							</div>	
						</div>
					</div>
					
					
					
				</div>
                
			</div>
		</div>
		
		<!-- Footer Bottom -->
		<div class="auto-container">				
            <div class="footer-bottom">
            	<div class="copyright">Copyright  2021</div>
			</div>
		</div>
	</footer>
</div>

<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fal fa-arrow-circle-up"></span></div>

<script type="text/javascript" src="../translate.google.com/translate_a/elementa0d8.js?cb=googleTranslateElementInit"></script>

<script src="assets/js/jquery.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/jquery.fancybox.js"></script>
<script src="assets/js/isotope.js"></script>
<script src="assets/js/owl.js"></script>
<script src="assets/js/appear.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/lazyload.js"></script>
<script src="assets/js/scrollbar.js"></script>
<script src="assets/js/TweenMax.min.js"></script>
<script src="assets/js/knob.js"></script>
<script src="assets/js/script.js"></script></body>
</html>